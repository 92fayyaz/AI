# Examples

## Contains the documentation for:

1. Creating AI Data Science Agents (e.g. Data Cleaning, Data Wrangling, Feature Engineering, etc)
2. Implementing techniques (e.g. human-in-the-loop, managing directories to store data pipelines (function storage), combining agents so they can talk to each other)

## Current Project Progress:

![Data Science Team](/img/ai_data_science_team.jpg)
