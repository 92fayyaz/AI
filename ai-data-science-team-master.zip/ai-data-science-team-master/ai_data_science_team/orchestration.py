# BUSINESS SCIENCE UNIVERSITY
# AI DATA SCIENCE TEAM
# ***
# Orchestration
# ai_data_science_team/orchestration.py

from ai_data_science_team.agents import data_cleaning_agent

# TODO - add orchestration

# def model_pipeline(model, log=True, log_path=None):
    
#     return "todo"
    
    
    
    